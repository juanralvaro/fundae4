import java.util.Scanner;

public class CalculadoraIMC {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar el peso al usuario
        System.out.print("Ingrese su peso en kilogramos (kg): ");
        double peso = leerEntrada(scanner);

        // Solicitar la altura al usuario
        System.out.print("Ingrese su altura en metros (m): ");
        double altura = leerEntrada(scanner);

        // Calcular el IMC
        double imc = calcularIMC(peso, altura);

        // Mostrar el IMC calculado
        System.out.printf("Su IMC es: %.2f\n", imc);

        // Mostrar la interpretación del IMC
        interpretarIMC(imc);

        scanner.close();
    }

    /**
     * Método para leer una entrada válida (acepta comas y puntos).
     *
     * @param scanner Objeto Scanner para leer la entrada del usuario.
     * @return El valor ingresado como double.
     */
    public static double leerEntrada(Scanner scanner) {
        double valor = -1;
        while (valor <= 0) {
            String entrada = scanner.nextLine().replace(",", "."); // Reemplazar comas por puntos
            if (entrada.matches("^[0-9]+(\\.[0-9]+)?$")) { // Validar formato numérico
                valor = Double.parseDouble(entrada); // Convertir a double
                if (valor <= 0) {
                    System.out.println("El valor debe ser positivo. Inténtelo de nuevo:");
                }
            } else {
                System.out.println("Entrada inválida. Por favor, ingrese un número válido:");
            }
        }
        return valor;
    }

    public static double calcularIMC(double peso, double altura) {
        return peso / (altura * altura);
    }

    public static void interpretarIMC(double imc) {
        if (imc < 18.5) {
            System.out.println("Clasificación: Bajo peso.");
        } else if (imc >= 18.5 && imc < 24.9) {
            System.out.println("Clasificación: Peso normal.");
        } else if (imc >= 25.0 && imc < 29.9) {
            System.out.println("Clasificación: Sobrepeso.");
        } else {
            System.out.println("Clasificación: Obesidad.");
        }
    }
}
