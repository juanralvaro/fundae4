using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace NewApplication.Views.Producto
{
    public class DetallesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
