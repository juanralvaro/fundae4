﻿using Microsoft.AspNetCore.Mvc;
using NewApplication.Models;
using System.Collections.Generic;

namespace MiAplicacion.Controllers
{
    public class ProductoController : Controller
    {
        private static List<Producto> productos = new List<Producto>
        {
            new Producto { Id = 1, Nombre = "Laptop", Precio = 1500 },
            new Producto { Id = 2, Nombre = "Teléfono", Precio = 800 }
        };

        public IActionResult Index()
        {
            return View(productos);
        }

        public IActionResult Detalles(int id)
        {
            var producto = productos.Find(p => p.Id == id);
            if (producto == null) return NotFound();
            return View(producto);
        }
    }
}

