# Servidor Express Básico

## Instrucciones para usar

1. Clona este repositorio.
2. Instala las dependencias con `npm install`.
3. Crea un archivo `.env` con el puerto deseado.
4. Inicia el servidor con `npm run dev`.

## Rutas disponibles

- **GET** `/api/data`: Obtener datos de ejemplo.
- **POST** `/api/data`: Enviar datos.
- **PUT** `/api/data/:id`: Actualizar datos por ID.
- **DELETE** `/api/data/:id`: Eliminar datos por ID.
