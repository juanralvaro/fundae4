require('dotenv').config();

// Importar las dependencias necesarias
const express = require('express');
const path = require('path');
const morgan = require('morgan');
const helmet = require('helmet');
const mongoose = require('mongoose');
const app = express();

// Configuración básica
const PORT = process.env.PORT || 3036;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:3016/miapp';

// Conectar a MongoDB
mongoose.connect(MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Conexión a MongoDB exitosa');
}).catch((err) => {
    console.error('Error al conectar a MongoDB:', err);
});

// Definir esquema y modelo de ejemplo
const DataSchema = new mongoose.Schema({
    name: { type: String, required: true },
    value: { type: String, required: true }
});
const DataModel = mongoose.model('Data', DataSchema);

// Middlewares
app.use(express.json()); // Parsear JSON en las solicitudes
app.use(express.urlencoded({ extended: true })); // Parsear datos de formularios
app.use(morgan('dev')); // Registro de solicitudes HTTP en la consola
app.use(helmet()); // Seguridad básica configurada automáticamente

// Servir contenido estático (p. ej., una página HTML)
app.use(express.static(path.join(__dirname, 'public')));

// Rutas

// Ruta GET para obtener datos de MongoDB
app.get('/api/data', async (req, res) => {
    try {
        const data = await DataModel.find();
        res.json({
            message: "Datos obtenidos correctamente",
            data
        });
    } catch (err) {
        res.status(500).json({ error: "Error al obtener los datos" });
    }
});

// Ruta POST para enviar datos a MongoDB
app.post('/api/data', async (req, res) => {
    const { name, value } = req.body;
    if (!name || !value) {
        return res.status(400).json({ error: "Se requieren 'name' y 'value'" });
    }
    try {
        const newData = new DataModel({ name, value });
        await newData.save();
        res.status(201).json({
            message: "Dato guardado correctamente",
            data: newData
        });
    } catch (err) {
        res.status(500).json({ error: "Error al guardar el dato" });
    }
});

// Ruta PUT para actualizar datos en MongoDB
app.put('/api/data/:id', async (req, res) => {
    const { id } = req.params;
    const { name, value } = req.body;
    if (!name || !value) {
        return res.status(400).json({ error: "Se requieren 'name' y 'value' para actualizar" });
    }
    try {
        const updatedData = await DataModel.findByIdAndUpdate(id, { name, value }, { new: true });
        if (!updatedData) {
            return res.status(404).json({ error: "Dato no encontrado" });
        }
        res.json({
            message: "Dato actualizado correctamente",
            data: updatedData
        });
    } catch (err) {
        res.status(500).json({ error: "Error al actualizar el dato" });
    }
});

// Ruta DELETE para eliminar datos en MongoDB
app.delete('/api/data/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const deletedData = await DataModel.findByIdAndDelete(id);
        if (!deletedData) {
            return res.status(404).json({ error: "Dato no encontrado" });
        }
        res.json({
            message: "Dato eliminado correctamente",
            data: deletedData
        });
    } catch (err) {
        res.status(500).json({ error: "Error al eliminar el dato" });
    }
});

// Manejo de errores
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: "Ocurrió un error en el servidor" });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});
