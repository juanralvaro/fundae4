const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const app = express();

// MongoDB connection
const mongoURI = 'mongodb+srv://<username>:<password>@cluster0.mongodb.net/mi_base_de_datos?retryWrites=true&w=majority'; // Replace with your MongoDB Atlas URI
mongoose.connect(mongoURI)
    .then(() => console.log('Conectado a MongoDB Atlas'))
    .catch(err => console.error('Error al conectar a MongoDB', err));

// Serve static files from the 'proyecto_curso/public' directory
app.use(express.static(path.join(__dirname, '../proyecto_curso/public')));

// Explicitly serve index.html
app.get('/index.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../proyecto_curso/public', 'index.html'));
});

const puerto = 3036; // Changed port number
app.listen(puerto, () => {
    console.log(`Servidor escuchando en el puerto ${puerto}`);
});